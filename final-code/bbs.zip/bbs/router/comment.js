const express = require("express")
const db = require("./common/db")
const redis = require("./common/redis_cli")
const time = require("./common/time")

module.exports = function(){

    const router = express.Router();

    router.get("/",(req , res)=>{
        if( req.session["userInfo"] ){
            let topic_id = req.query.topic_id
            let list_id = req.query.list_id
            db.pool.query("select title from bbs_list where id=? limit 1",[list_id],(err,data)=>{
                if(!err){
                    res.render("comment.ejs",{topic_id:topic_id,list_id:list_id,title:data[0].title})
                }
            })
            
        }else{
            res.redirect("/user/login")
        }

    })

    router.post("/reply",(req,res)=>{
        if( req.session["userInfo"] ){
            let topic_id = req.body.topic_id
            let list_id = req.body.list_id
            let user_id = req.session["userInfo"].id
            let contents = req.body.txtContent //获取回复内容
            let now = time.now()
            let promise = new Promise( (resolve,reject)=>{
                db.pool.query("insert into bbs_comment(topic_id,list_id,user_id,re_time,content)values(?,?,?,?,?)",[topic_id,list_id,user_id,now,contents],(err)=>{
                    if(!err){
                        resolve()
                    }
                })
            } )

            promise.then( ()=>{
                let hashKey = "topic:"+topic_id
                let hashField = "list_id_" + list_id
                redis.cli.hget(hashKey,hashField,(err,v)=>{
                    if(!err && v){
                        redis.cli.hset(hashKey,hashField,parseInt(v)+1,(err)=>{
                            res.redirect("/details?list_id=" + list_id)
                        })
                    }else if(!err && !v){
                        redis.cli.hset(hashKey,hashField,1,(err)=>{
                            res.redirect("/details?list_id=" + list_id)
                        })
                    }
                })
            } )

        }else{
            res.redirect("/user/login")
        }
    })

    






    return router;
}