const express = require("express")
const redis = require("./common/redis_cli")
const db = require("./common/db")
const time = require("./common/time")

module.exports = function(){

    const router = express.Router();

    router.get("/",(req , res)=>{
        
        let list_id = req.query.list_id
        let premeters = {}
        function * getCommetList(){
            //获取论坛帖子的发表
            premeters = yield db.pool.query("SELECT lst.topic_id,lst.id AS id,title,content,username,nickname,thumbnail,pub_time FROM bbs_list AS lst LEFT JOIN bbs_users AS users ON lst.`user_id`=users.id WHERE lst.id=? limit 1",[list_id],(err,data)=>{
                if(!err){
                    data[0].pub_time = time.date( data[0].pub_time )
                    premeters.listData = data[0]
                    //res.render("details.ejs",{listData:premeters.listData})
                    it.next(premeters)
                }
            })

            //获取回复
            premeters = yield db.pool.query("SELECT content,nickname,username,thumbnail,re_time FROM bbs_comment AS cm LEFT JOIN bbs_users users ON cm.user_id=users.id WHERE cm.list_id=?",[list_id],(err,data)=>{
                if(!err){

                    premeters.reply = data;
                    premeters.replyCount = data.length;
                    res.render("details.ejs",{listData:premeters.listData,reply:premeters.reply,replyCount:premeters.replyCount,time:time})
                    it.next(premeters)
                }
            })


        }
        let it = getCommetList()
        it.next()   
    })






    return router;
}