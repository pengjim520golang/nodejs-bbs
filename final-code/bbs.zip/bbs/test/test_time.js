const time = require("../router/common/time")

 console.log( time.now() )

 console.log( time.getDatetime() )